package com.simongolda.bonuze

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
