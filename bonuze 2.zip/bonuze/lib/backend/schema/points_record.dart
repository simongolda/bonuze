import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'points_record.g.dart';

abstract class PointsRecord
    implements Built<PointsRecord, PointsRecordBuilder> {
  static Serializer<PointsRecord> get serializer => _$pointsRecordSerializer;

  @BuiltValueField(wireName: 'created_at')
  DateTime? get createdAt;

  int? get points;

  @BuiltValueField(wireName: 'user_created')
  DocumentReference? get userCreated;

  DocumentReference? get store;

  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference? get ffRef;
  DocumentReference get reference => ffRef!;

  static void _initializeBuilder(PointsRecordBuilder builder) =>
      builder..points = 0;

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('points');

  static Stream<PointsRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  static Future<PointsRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  PointsRecord._();
  factory PointsRecord([void Function(PointsRecordBuilder) updates]) =
      _$PointsRecord;

  static PointsRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference})!;
}

Map<String, dynamic> createPointsRecordData({
  DateTime? createdAt,
  int? points,
  DocumentReference? userCreated,
  DocumentReference? store,
}) {
  final firestoreData = serializers.toFirestore(
    PointsRecord.serializer,
    PointsRecord(
      (p) => p
        ..createdAt = createdAt
        ..points = points
        ..userCreated = userCreated
        ..store = store,
    ),
  );

  return firestoreData;
}
