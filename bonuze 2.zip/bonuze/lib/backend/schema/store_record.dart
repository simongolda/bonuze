import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'store_record.g.dart';

abstract class StoreRecord implements Built<StoreRecord, StoreRecordBuilder> {
  static Serializer<StoreRecord> get serializer => _$storeRecordSerializer;

  @BuiltValueField(wireName: 'created_at')
  DateTime? get createdAt;

  bool? get published;

  BuiltList<DocumentReference>? get employees;

  String? get name;

  String? get street;

  String? get city;

  @BuiltValueField(wireName: 'store_owner')
  DocumentReference? get storeOwner;

  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference? get ffRef;
  DocumentReference get reference => ffRef!;

  static void _initializeBuilder(StoreRecordBuilder builder) => builder
    ..published = false
    ..employees = ListBuilder()
    ..name = ''
    ..street = ''
    ..city = '';

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('store');

  static Stream<StoreRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  static Future<StoreRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  StoreRecord._();
  factory StoreRecord([void Function(StoreRecordBuilder) updates]) =
      _$StoreRecord;

  static StoreRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference})!;
}

Map<String, dynamic> createStoreRecordData({
  DateTime? createdAt,
  bool? published,
  String? name,
  String? street,
  String? city,
  DocumentReference? storeOwner,
}) {
  final firestoreData = serializers.toFirestore(
    StoreRecord.serializer,
    StoreRecord(
      (s) => s
        ..createdAt = createdAt
        ..published = published
        ..employees = null
        ..name = name
        ..street = street
        ..city = city
        ..storeOwner = storeOwner,
    ),
  );

  return firestoreData;
}
