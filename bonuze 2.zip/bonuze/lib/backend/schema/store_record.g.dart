// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'store_record.dart';

// **************************************************************************
// BuiltValueGenerator
// **************************************************************************

Serializer<StoreRecord> _$storeRecordSerializer = new _$StoreRecordSerializer();

class _$StoreRecordSerializer implements StructuredSerializer<StoreRecord> {
  @override
  final Iterable<Type> types = const [StoreRecord, _$StoreRecord];
  @override
  final String wireName = 'StoreRecord';

  @override
  Iterable<Object?> serialize(Serializers serializers, StoreRecord object,
      {FullType specifiedType = FullType.unspecified}) {
    final result = <Object?>[];
    Object? value;
    value = object.createdAt;
    if (value != null) {
      result
        ..add('created_at')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(DateTime)));
    }
    value = object.published;
    if (value != null) {
      result
        ..add('published')
        ..add(
            serializers.serialize(value, specifiedType: const FullType(bool)));
    }
    value = object.employees;
    if (value != null) {
      result
        ..add('employees')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(BuiltList, const [
              const FullType(
                  DocumentReference, const [const FullType.nullable(Object)])
            ])));
    }
    value = object.name;
    if (value != null) {
      result
        ..add('name')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.street;
    if (value != null) {
      result
        ..add('street')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.city;
    if (value != null) {
      result
        ..add('city')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.storeOwner;
    if (value != null) {
      result
        ..add('store_owner')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(
                DocumentReference, const [const FullType.nullable(Object)])));
    }
    value = object.ffRef;
    if (value != null) {
      result
        ..add('Document__Reference__Field')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(
                DocumentReference, const [const FullType.nullable(Object)])));
    }
    return result;
  }

  @override
  StoreRecord deserialize(Serializers serializers, Iterable<Object?> serialized,
      {FullType specifiedType = FullType.unspecified}) {
    final result = new StoreRecordBuilder();

    final iterator = serialized.iterator;
    while (iterator.moveNext()) {
      final key = iterator.current! as String;
      iterator.moveNext();
      final Object? value = iterator.current;
      switch (key) {
        case 'created_at':
          result.createdAt = serializers.deserialize(value,
              specifiedType: const FullType(DateTime)) as DateTime?;
          break;
        case 'published':
          result.published = serializers.deserialize(value,
              specifiedType: const FullType(bool)) as bool?;
          break;
        case 'employees':
          result.employees.replace(serializers.deserialize(value,
              specifiedType: const FullType(BuiltList, const [
                const FullType(
                    DocumentReference, const [const FullType.nullable(Object)])
              ]))! as BuiltList<Object?>);
          break;
        case 'name':
          result.name = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'street':
          result.street = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'city':
          result.city = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'store_owner':
          result.storeOwner = serializers.deserialize(value,
              specifiedType: const FullType(DocumentReference, const [
                const FullType.nullable(Object)
              ])) as DocumentReference<Object?>?;
          break;
        case 'Document__Reference__Field':
          result.ffRef = serializers.deserialize(value,
              specifiedType: const FullType(DocumentReference, const [
                const FullType.nullable(Object)
              ])) as DocumentReference<Object?>?;
          break;
      }
    }

    return result.build();
  }
}

class _$StoreRecord extends StoreRecord {
  @override
  final DateTime? createdAt;
  @override
  final bool? published;
  @override
  final BuiltList<DocumentReference<Object?>>? employees;
  @override
  final String? name;
  @override
  final String? street;
  @override
  final String? city;
  @override
  final DocumentReference<Object?>? storeOwner;
  @override
  final DocumentReference<Object?>? ffRef;

  factory _$StoreRecord([void Function(StoreRecordBuilder)? updates]) =>
      (new StoreRecordBuilder()..update(updates))._build();

  _$StoreRecord._(
      {this.createdAt,
      this.published,
      this.employees,
      this.name,
      this.street,
      this.city,
      this.storeOwner,
      this.ffRef})
      : super._();

  @override
  StoreRecord rebuild(void Function(StoreRecordBuilder) updates) =>
      (toBuilder()..update(updates)).build();

  @override
  StoreRecordBuilder toBuilder() => new StoreRecordBuilder()..replace(this);

  @override
  bool operator ==(Object other) {
    if (identical(other, this)) return true;
    return other is StoreRecord &&
        createdAt == other.createdAt &&
        published == other.published &&
        employees == other.employees &&
        name == other.name &&
        street == other.street &&
        city == other.city &&
        storeOwner == other.storeOwner &&
        ffRef == other.ffRef;
  }

  @override
  int get hashCode {
    return $jf($jc(
        $jc(
            $jc(
                $jc(
                    $jc(
                        $jc($jc($jc(0, createdAt.hashCode), published.hashCode),
                            employees.hashCode),
                        name.hashCode),
                    street.hashCode),
                city.hashCode),
            storeOwner.hashCode),
        ffRef.hashCode));
  }

  @override
  String toString() {
    return (newBuiltValueToStringHelper(r'StoreRecord')
          ..add('createdAt', createdAt)
          ..add('published', published)
          ..add('employees', employees)
          ..add('name', name)
          ..add('street', street)
          ..add('city', city)
          ..add('storeOwner', storeOwner)
          ..add('ffRef', ffRef))
        .toString();
  }
}

class StoreRecordBuilder implements Builder<StoreRecord, StoreRecordBuilder> {
  _$StoreRecord? _$v;

  DateTime? _createdAt;
  DateTime? get createdAt => _$this._createdAt;
  set createdAt(DateTime? createdAt) => _$this._createdAt = createdAt;

  bool? _published;
  bool? get published => _$this._published;
  set published(bool? published) => _$this._published = published;

  ListBuilder<DocumentReference<Object?>>? _employees;
  ListBuilder<DocumentReference<Object?>> get employees =>
      _$this._employees ??= new ListBuilder<DocumentReference<Object?>>();
  set employees(ListBuilder<DocumentReference<Object?>>? employees) =>
      _$this._employees = employees;

  String? _name;
  String? get name => _$this._name;
  set name(String? name) => _$this._name = name;

  String? _street;
  String? get street => _$this._street;
  set street(String? street) => _$this._street = street;

  String? _city;
  String? get city => _$this._city;
  set city(String? city) => _$this._city = city;

  DocumentReference<Object?>? _storeOwner;
  DocumentReference<Object?>? get storeOwner => _$this._storeOwner;
  set storeOwner(DocumentReference<Object?>? storeOwner) =>
      _$this._storeOwner = storeOwner;

  DocumentReference<Object?>? _ffRef;
  DocumentReference<Object?>? get ffRef => _$this._ffRef;
  set ffRef(DocumentReference<Object?>? ffRef) => _$this._ffRef = ffRef;

  StoreRecordBuilder() {
    StoreRecord._initializeBuilder(this);
  }

  StoreRecordBuilder get _$this {
    final $v = _$v;
    if ($v != null) {
      _createdAt = $v.createdAt;
      _published = $v.published;
      _employees = $v.employees?.toBuilder();
      _name = $v.name;
      _street = $v.street;
      _city = $v.city;
      _storeOwner = $v.storeOwner;
      _ffRef = $v.ffRef;
      _$v = null;
    }
    return this;
  }

  @override
  void replace(StoreRecord other) {
    ArgumentError.checkNotNull(other, 'other');
    _$v = other as _$StoreRecord;
  }

  @override
  void update(void Function(StoreRecordBuilder)? updates) {
    if (updates != null) updates(this);
  }

  @override
  StoreRecord build() => _build();

  _$StoreRecord _build() {
    _$StoreRecord _$result;
    try {
      _$result = _$v ??
          new _$StoreRecord._(
              createdAt: createdAt,
              published: published,
              employees: _employees?.build(),
              name: name,
              street: street,
              city: city,
              storeOwner: storeOwner,
              ffRef: ffRef);
    } catch (_) {
      late String _$failedField;
      try {
        _$failedField = 'employees';
        _employees?.build();
      } catch (e) {
        throw new BuiltValueNestedFieldError(
            r'StoreRecord', _$failedField, e.toString());
      }
      rethrow;
    }
    replace(_$result);
    return _$result;
  }
}

// ignore_for_file: always_put_control_body_on_new_line,always_specify_types,annotate_overrides,avoid_annotating_with_dynamic,avoid_as,avoid_catches_without_on_clauses,avoid_returning_this,deprecated_member_use_from_same_package,lines_longer_than_80_chars,no_leading_underscores_for_local_identifiers,omit_local_variable_types,prefer_expression_function_bodies,sort_constructors_first,test_types_in_equals,unnecessary_const,unnecessary_new,unnecessary_lambdas
