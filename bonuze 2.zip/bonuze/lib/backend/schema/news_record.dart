import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'news_record.g.dart';

abstract class NewsRecord implements Built<NewsRecord, NewsRecordBuilder> {
  static Serializer<NewsRecord> get serializer => _$newsRecordSerializer;

  @BuiltValueField(wireName: 'created_at')
  DateTime? get createdAt;

  bool? get published;

  @BuiltValueField(wireName: 'user_created')
  DocumentReference? get userCreated;

  DocumentReference? get store;

  String? get title;

  String? get subtitle;

  @BuiltValueField(wireName: 'expiration_date')
  DateTime? get expirationDate;

  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference? get ffRef;
  DocumentReference get reference => ffRef!;

  static void _initializeBuilder(NewsRecordBuilder builder) => builder
    ..published = false
    ..title = ''
    ..subtitle = '';

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('news');

  static Stream<NewsRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  static Future<NewsRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  NewsRecord._();
  factory NewsRecord([void Function(NewsRecordBuilder) updates]) = _$NewsRecord;

  static NewsRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference})!;
}

Map<String, dynamic> createNewsRecordData({
  DateTime? createdAt,
  bool? published,
  DocumentReference? userCreated,
  DocumentReference? store,
  String? title,
  String? subtitle,
  DateTime? expirationDate,
}) {
  final firestoreData = serializers.toFirestore(
    NewsRecord.serializer,
    NewsRecord(
      (n) => n
        ..createdAt = createdAt
        ..published = published
        ..userCreated = userCreated
        ..store = store
        ..title = title
        ..subtitle = subtitle
        ..expirationDate = expirationDate,
    ),
  );

  return firestoreData;
}
