import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyDBqPONpIL8kChJNVk0UOUU7vKukMJ7zOA",
            authDomain: "bonuze-app.firebaseapp.com",
            projectId: "bonuze-app",
            storageBucket: "bonuze-app.appspot.com",
            messagingSenderId: "1091324574106",
            appId: "1:1091324574106:web:6dcc72ee1af5a67caca223"));
  } else {
    await Firebase.initializeApp();
  }
}
